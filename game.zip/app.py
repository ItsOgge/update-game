print("🎮 Welcome to my cool app!")

# UPDATE!!!